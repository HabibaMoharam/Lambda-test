package forgotpassword;

import base.BaseTests;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.ForgotPasswordPage;

public class ForgotPasswordTestCases extends BaseTests {

    @Test(priority = 1)
    public void testForgotPasswordWithValidEmail() {
        ForgotPasswordPage forgotPasswordPage = new ForgotPasswordPage(driver);

        forgotPasswordPage.openForgotPasswordPage();
        forgotPasswordPage.enterEmail("john.doe01@testmail.com");
        forgotPasswordPage.clickContinueButton();

        String expectedResult = "An email with a confirmation link has been sent your email address.";

        forgotPasswordPage.waitForTextOnPage(expectedResult);

        String actualResult = forgotPasswordPage.getPageText();


        Assert.assertTrue(
                actualResult.contains(expectedResult),
                "Success message was not found. Actual text: " + actualResult
        );
    }

    @Test(priority = 2)
    public void testForgotPasswordWithInvalidEmail() {
        ForgotPasswordPage forgotPasswordPage = new ForgotPasswordPage(driver);

        forgotPasswordPage.openForgotPasswordPage();
        forgotPasswordPage.enterEmail("habibamoharam24");
        forgotPasswordPage.clickContinueButton();

        String expectedResult = "Warning: The E-Mail Address was not found in our records, please try again!";

        forgotPasswordPage.waitForTextOnPage(expectedResult);

        String actualResult = forgotPasswordPage.getPageText();


        Assert.assertTrue(
                actualResult.contains(expectedResult),
                "Warning message was not found. Actual text: " + actualResult
        );
    }
}