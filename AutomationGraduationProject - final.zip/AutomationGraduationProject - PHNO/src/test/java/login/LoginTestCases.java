package login;

import base.BaseTests;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;

public class LoginTestCases extends BaseTests {

    @Test(priority = 1)
    public void testSuccessfulLoginWithValidCredentials() {
        LoginPage loginPage = homePage.clickOnLogin();

        loginPage.enterEmail("john.doe01@testmail.com");
        loginPage.enterPassword("Test@1234");
        loginPage.clickOnLoginButton();

        String actualResult = loginPage.getMyAccountTitle();
        String expectedResult = "My Account";
        Assert.assertTrue(actualResult.contains(expectedResult));
    }

    @Test(priority = 2)
    public void testLoginWithCorrectEmailButWrongPassword() {
        LoginPage loginPage = homePage.clickOnLogin();

        loginPage.enterEmail("john.doe01@testmail.com");
        loginPage.enterPassword("WrongPass!99");
        loginPage.clickOnLoginButton();

        String actualResult = loginPage.getErrorMessage();
        String expectedResult = "Warning: No match for E-Mail Address and/or Password.";
        Assert.assertTrue(actualResult.contains(expectedResult));
    }

    @Test(priority = 3)
    public void testLoginWithUnregisteredEmailAddress() {
        LoginPage loginPage = homePage.clickOnLogin();

        loginPage.enterEmail("notregistereddd@testmail.com");
        loginPage.enterPassword("Test@1234");
        loginPage.clickOnLoginButton();

        String actualResult = loginPage.getErrorMessage();
        String expectedResult = "Warning: No match for E-Mail Address and/or Password.";
        Assert.assertTrue(actualResult.contains(expectedResult));
    }
}