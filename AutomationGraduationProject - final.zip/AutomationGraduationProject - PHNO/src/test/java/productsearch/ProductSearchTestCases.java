package productsearch;

import base.BaseTests;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.ProductSearchPage;

public class ProductSearchTestCases extends BaseTests {

    @Test(priority = 1)
    public void testFullProductName(){
        homePage.EnterSearchText("HTC Touch HD");
        ProductSearchPage productSearchPage = homePage.clickOnSearchButton();
        String actualResult = productSearchPage.getProductName();
        String expectedResult = "HTC Touch HD";
        Assert.assertTrue(actualResult.contains(expectedResult));

    }

    @Test(priority = 2)
    public void testPartialProductName(){
        homePage.EnterSearchText("HTC");
        ProductSearchPage productSearchPage = homePage.clickOnSearchButton();
        String actualResult = productSearchPage.getProductName();
        String expectedResult = "HTC Touch HD";
        Assert.assertTrue(actualResult.contains(expectedResult));

    }

    @Test(priority = 3)
    public void testLowerCaseProductName(){
        homePage.EnterSearchText("htc touch hd");
        ProductSearchPage productSearchPage = homePage.clickOnSearchButton();
        String actualResult = productSearchPage.getProductName();
        String expectedResult = "HTC Touch HD";
        Assert.assertTrue(actualResult.contains(expectedResult));

    }


    @Test(priority = 4)
    public void testUpperCaseProductName(){
        homePage.EnterSearchText("HTC TOUCH HD");
        ProductSearchPage productSearchPage = homePage.clickOnSearchButton();
        String actualResult = productSearchPage.getProductName();
        String expectedResult = "HTC Touch HD";
        Assert.assertTrue(actualResult.contains(expectedResult));

    }


    @Test(priority = 5)
    public void testLeadingWhitespaceCharactersProductName(){
        homePage.EnterSearchText("        HTC Touch HD");
        ProductSearchPage productSearchPage = homePage.clickOnSearchButton();
        String actualResult = productSearchPage.getProductName();
        String expectedResult = "HTC Touch HD";
        Assert.assertTrue(actualResult.contains(expectedResult));

    }

    @Test(priority = 6)
    public void testProductNameNotExist(){
        homePage.EnterSearchText("oven");
        ProductSearchPage productSearchPage = homePage.clickOnSearchButton();
        String actualResult = productSearchPage.getErrorMessage();
        String expectedResult = "There is no product that matches the search criteria.";
        Assert.assertTrue(actualResult.contains(expectedResult));

    }

}
