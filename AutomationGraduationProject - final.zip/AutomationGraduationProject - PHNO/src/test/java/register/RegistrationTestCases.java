package register;

import base.BaseTests;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.RegistrationPage;

public class RegistrationTestCases extends BaseTests {

    @Test(priority = 1)
    public void testSuccessfulRegistrationWithValidData() {
        RegistrationPage registrationPage = homePage.clickOnRegister();

        registrationPage.enterFirstName("John");
        registrationPage.enterLastName("Doe");
        registrationPage.enterEmail("habiba" + System.currentTimeMillis() + "@testmail.com");
        registrationPage.enterTelephone("9876543210");
        registrationPage.enterPassword("Test@1234");
        registrationPage.enterConfirmPassword("Test@1234");
        registrationPage.clickOnPrivacyPolicy();
        registrationPage.clickOnContinueButton();

        String actualResult = registrationPage.getSuccessMessage();
        String expectedResult = "Your Account Has Been Created!";
        Assert.assertTrue(actualResult.contains(expectedResult));
    }

    @Test(priority = 2)
    public void testRegistrationWithAlreadyRegisteredEmail() {
        RegistrationPage registrationPage = homePage.clickOnRegister();

        registrationPage.enterFirstName("John");
        registrationPage.enterLastName("Doe");
        registrationPage.enterEmail("john.doe01@testmail.com");
        registrationPage.enterTelephone("9876543210");
        registrationPage.enterPassword("Test@1234");
        registrationPage.enterConfirmPassword("Test@1234");
        registrationPage.clickOnPrivacyPolicy();
        registrationPage.clickOnContinueButton();

        String actualResult = registrationPage.getWarningMessage();
        String expectedResult = "Warning: E-Mail Address is already registered!";
        Assert.assertTrue(actualResult.contains(expectedResult));
    }

    @Test(priority = 3)
    public void testRegistrationWithBlankFirstName() {
        RegistrationPage registrationPage = homePage.clickOnRegister();

        registrationPage.enterLastName("Doe");
        registrationPage.enterEmail("habiba" + System.currentTimeMillis() + "@testmail.com");
        registrationPage.enterTelephone("9876543210");
        registrationPage.enterPassword("Test@1234");
        registrationPage.enterConfirmPassword("Test@1234");
        registrationPage.clickOnPrivacyPolicy();
        registrationPage.clickOnContinueButton();

        String actualResult = registrationPage.getFirstNameErrorMessage();
        String expectedResult = "First Name must be between 1 and 32 characters!";
        Assert.assertTrue(actualResult.contains(expectedResult));
    }
}