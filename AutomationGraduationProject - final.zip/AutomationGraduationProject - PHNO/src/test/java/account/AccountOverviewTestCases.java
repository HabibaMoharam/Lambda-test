package account;

import base.BaseTests;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.AccountPage;
import pages.LoginPage;

public class AccountOverviewTestCases extends BaseTests {

    @Test(priority = 1)
    public void testUserCanViewDashboard() {
        LoginPage loginPage = homePage.clickOnLogin();

        loginPage.enterEmail("john.doe01@testmail.com");
        loginPage.enterPassword("Test@1234");
        loginPage.clickOnLoginButton();

        AccountPage accountPage = new AccountPage(driver);

        String actualResult = accountPage.getMyAccountHeading();
        String expectedResult = "My Account";

        Assert.assertTrue(actualResult.contains(expectedResult));
    }

    @Test(priority = 2)
    public void testUserCanViewPersonalDetailsPage() {
        LoginPage loginPage = homePage.clickOnLogin();

        loginPage.enterEmail("john.doe01@testmail.com");
        loginPage.enterPassword("Test@1234");
        loginPage.clickOnLoginButton();

        AccountPage accountPage = new AccountPage(driver);
        accountPage.clickEditAccountInformation();

        String actualUrl = driver.getCurrentUrl();

        Assert.assertTrue(actualUrl.contains("account/edit"));
    }
}