package account;

import base.BaseTests;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.AccountPage;
import pages.EditAccountPage;
import pages.LoginPage;

public class EditAccountInformationTestCases extends BaseTests {

    @Test(priority = 1)
    public void testUserCanEditPersonalInformation() {
        LoginPage loginPage = homePage.clickOnLogin();

        loginPage.enterEmail("john.doe01@testmail.com");
        loginPage.enterPassword("Test@1234");
        loginPage.clickOnLoginButton();

        AccountPage accountPage = new AccountPage(driver);
        accountPage.clickEditAccountInformation();

        EditAccountPage editAccountPage = new EditAccountPage(driver);

        editAccountPage.clearFirstName();
        editAccountPage.clearLastName();
        editAccountPage.clearTelephone();

        editAccountPage.enterFirstName("Omar");
        editAccountPage.enterLastName("Ahmed");
        editAccountPage.enterTelephone("01234567890");
        editAccountPage.clickContinueButton();

        String actualResult = editAccountPage.getSuccessMessage();
        Assert.assertTrue(actualResult.contains("Success: Your account has been successfully updated."));
    }

    @Test(priority = 2)
    public void testRequiredFieldsValidation() {
        LoginPage loginPage = homePage.clickOnLogin();

        loginPage.enterEmail("john.doe01@testmail.com");
        loginPage.enterPassword("Test@1234");
        loginPage.clickOnLoginButton();

        AccountPage accountPage = new AccountPage(driver);
        accountPage.clickEditAccountInformation();

        EditAccountPage editAccountPage = new EditAccountPage(driver);

        editAccountPage.clearFirstName();
        editAccountPage.clearLastName();
        editAccountPage.clickContinueButton();

        String actualResult = editAccountPage.getFirstNameErrorMessage();
        String expectedResult = "First Name must be between 1 and 32 characters!";

        Assert.assertTrue(actualResult.contains(expectedResult));
    }
}