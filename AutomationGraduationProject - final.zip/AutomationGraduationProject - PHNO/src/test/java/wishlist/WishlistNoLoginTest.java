package wishlist;

import base.BaseTests;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.BrandPage;
import pages.HomePage;
import pages.ProductPage;

public class WishlistNoLoginTest extends BaseTests {

    @Test
    public void verifyWishlistShowsLoginPromptWhenNotLoggedIn() {

        // ── Step 1: Create page objects ───────────────────────────────────
        // ✅ NO LoginPage — user is not logged in
        HomePage    homePage    = new HomePage(driver, wait);
        BrandPage   brandPage   = new BrandPage(driver, wait);
        ProductPage productPage = new ProductPage(driver, wait);

        // ── Step 2: Wait for home page to load ────────────────────────────
        // ✅ REUSED — driver already opened the site in BaseTest.setUp()
        homePage.waitForPageToLoad();
        System.out.println("✅ Home page loaded — user is NOT logged in");

        // ── Step 3: Navigate Mega Menu → Apple brand page ─────────────────
        // ✅ REUSED — same as all previous tests
        homePage.navigateToAppleBrand();

        // ── Step 4: Confirm we are on Apple brand page ────────────────────
        // ✅ REUSED — same as previous tests
        String brandName = brandPage.getBrandName();
        System.out.println("✅ On brand page: " + brandName);

        // ── Step 5: Click iPod Shuffle ────────────────────────────────────
        // ✅ REUSED — same as all previous tests
        homePage.clickProductByViewCount();

        // ── Step 6: Wait for product detail page to load ──────────────────
        // ✅ REUSED — same as all previous tests
        productPage.waitForPageToLoad();
        System.out.println("✅ Product detail page loaded: " + driver.getCurrentUrl());

        // ── Step 7: Read product title for logging ────────────────────────
        // ✅ REUSED — same as all previous tests
        String productTitle = productPage.getProductTitle();
        System.out.println("✅ Product name: " + productTitle);

        // ── Step 8: Click "Add to Wishlist" without being logged in ───────
        // ✅ REUSED — site will show login prompt popup instead of adding
        productPage.clickAddToWishlist();
        System.out.println("✅ Add to Wishlist clicked — expecting login prompt");



        // ── Step 9: Assert login prompt popup is displayed ────────────────
        // ✅ NEW — isLoginPromptDisplayed() checks for the modal popup
        // The popup shows: "You must login or create an account to save
        // iPod Shuffle to your wish list!"
        Assert.assertTrue(
                productPage.isLoginPromptDisplayed(),
                "Login prompt was NOT displayed after clicking wishlist without login!"
        );
        System.out.println("✅ Assertion passed — login prompt displayed correctly");
    }
}