package wishlist;

import base.BaseTests;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class WishlistTest extends BaseTests {


    // ── Test credentials ──────────────────────────────────────────────────
    private final String email    = "jojo@hotmail.com";
    private final String password = "test@222";

    @Test
    public void verifyAddToWishlist() {

        // ── Step 1: Create page objects ───────────────────────────────────
        HomePage    homePage    = new HomePage(driver, wait);
        LoginPagePro loginPage   = new LoginPagePro(driver, wait);
        BrandPage   brandPage   = new BrandPage(driver, wait);
        ProductPage productPage = new ProductPage(driver, wait);

        // ── Step 2: Login ─────────────────────────────────────────────────
        // ✅ REUSED — exact same as all previous tests
        loginPage.loginAs(
                homePage.getMyAccountMenu(),
                email,
                password
        );
        Assert.assertTrue(
                loginPage.getCurrentUrl().contains("account/account"),
                "Login failed! Cannot proceed to wishlist test."
        );
        System.out.println("✅ Login successful");

        // ── Step 3: Go back to home page ──────────────────────────────────
        // ✅ REUSED — same as all previous tests
        driver.navigate().to("https://ecommerce-playground.lambdatest.io/");
        homePage.waitForPageToLoad();
        System.out.println("✅ Home page loaded");

        // ── Step 4: Navigate Mega Menu → Apple brand page ─────────────────
        // ✅ REUSED — same as all previous tests
        homePage.navigateToAppleBrand();

        // ── Step 5: Confirm we are on Apple brand page ────────────────────
        // ✅ REUSED — same as previous tests
        String brandName = brandPage.getBrandName();
        System.out.println("✅ On brand page: " + brandName);

        // ── Step 6: Click iPod Shuffle ────────────────────────────────────
        // ✅ REUSED — same as ProductViewTest and AskQuestionTest
        homePage.clickProductByViewCount();

        // ── Step 7: Wait for product detail page to load ──────────────────
        // ✅ REUSED — same as all previous tests
        productPage.waitForPageToLoad();
        System.out.println("✅ Product detail page loaded: " + driver.getCurrentUrl());

        // ── Step 8: Read product title for logging ────────────────────────
        // ✅ REUSED — same as all previous tests
        String productTitle = productPage.getProductTitle();
        System.out.println("✅ Product name: " + productTitle);

        // ── Step 9: Click "Add to Wishlist" button ────────────────────────
        // ✅ NEW — clickAddToWishlist() added in Step 1
        productPage.clickAddToWishlist();
        System.out.println("✅ Add to Wishlist button clicked");

        // ── Step 10: Read the confirmation message ────────────────────────
        // ✅ NEW — getConfirmationMessage() added in Step 1
        String confirmationMessage = productPage.getConfirmationMessage();

        // ── Step 11: Assertion 1 — message is displayed (not empty) ──────
//        Assert.assertFalse(
//                confirmationMessage.isEmpty(),
//                "Confirmation message is empty! No feedback shown to user."
//        );
        System.out.println("✅ Assertion 1 passed — confirmation message displayed");

        // ── Step 12: Assertion 2 — message contains success keyword ──────
        // The site shows: "Success: You have added iPod Shuffle to your wish list!"
        Assert.assertTrue(
                confirmationMessage.toLowerCase().contains("wish list") ||
                        confirmationMessage.toLowerCase().contains("success"),
                "Confirmation message does not indicate success! Actual: [" + confirmationMessage + "]"
        );
        System.out.println("✅ Assertion 2 passed — message confirms wishlist addition");
        System.out.println("✅ Full message: [" + confirmationMessage + "]");

        String message = productPage.getConfirmationMessage();

        System.out.println("Returned message: " + message);

        Assert.assertTrue(
                message.toLowerCase().contains("success")
                        || message.toLowerCase().contains("wishlist"),
                "Wishlist confirmation message NOT displayed!"
        );
    }


}