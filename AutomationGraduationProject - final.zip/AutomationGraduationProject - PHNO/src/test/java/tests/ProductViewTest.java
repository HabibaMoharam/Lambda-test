package tests;

import base.BaseTests;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class ProductViewTest extends BaseTests {

    // ── Test credentials ──────────────────────────────────────────────────
    private final String email    = "jojo@hotmail.com";
    private final String password = "test@222";

    @Test
    public void verifyProductViewCountIsNumeric() {

        // ── Step 1: Create page objects ───────────────────────────────────
        HomePage    homePage    = new HomePage(driver, wait);
        LoginPagePro loginPage   = new LoginPagePro(driver, wait);
        BrandPage   brandPage   = new BrandPage(driver, wait);
        ProductPage productPage = new ProductPage(driver, wait);

        // ── Step 2: Login ─────────────────────────────────────────────────
        // ✅ REUSED — exact same as LoginTest and ProductCodeTest
        loginPage.loginAs(
                homePage.getMyAccountMenu(),
                email,
                password
        );
        Assert.assertTrue(
                loginPage.getCurrentUrl().contains("account/account"),
                "Login failed! Cannot proceed to product view test."
        );
        System.out.println("✅ Login successful");

        // ── Step 3: Go back to home page ──────────────────────────────────
        // ✅ REUSED — same as ProductCodeTest
        driver.navigate().to("https://ecommerce-playground.lambdatest.io/");
        homePage.waitForPageToLoad();
        System.out.println("✅ Home page loaded");

        // ── Step 4: Navigate Mega Menu → Apple brand page ─────────────────
        // ✅ REUSED — same as LoginTest and ProductCodeTest
        homePage.navigateToAppleBrand();

        // ── Step 5: Confirm we are on Apple brand page ────────────────────
        // ✅ REUSED — getBrandName() already exists in BrandPage
        String brandName = brandPage.getBrandName();
        System.out.println("✅ On brand page: " + brandName);

        // ── Step 6: Click iPod Shuffle (view count 87862) ─────────────────
        // ✅ NEW METHOD — clickProductByViewCount() added in Step 1
        homePage.clickProductByViewCount();

        // ── Step 7: Wait for product detail page to load ──────────────────
        // ✅ REUSED — same as ProductCodeTest
        productPage.waitForPageToLoad();
        System.out.println("✅ Product detail page loaded: " + driver.getCurrentUrl());

        // ── Step 8: Read product title for logging ────────────────────────
        // ✅ REUSED — same as ProductCodeTest
        String productTitle = productPage.getProductTitle();
        System.out.println("✅ Product name: " + productTitle);

        // ── Step 9: Read the view count ───────────────────────────────────
        // ✅ NEW METHOD — getViewCount() added in Step 2
        String viewCount = productPage.getViewCount();

        // ── Step 10: Assertion 1 — view count is displayed (not empty) ────
        Assert.assertFalse(
                viewCount.isEmpty(),
                "View count is empty! It should be displayed on the page."
        );
        System.out.println("✅ Assertion 1 passed — view count is displayed: " + viewCount);

        // ── Step 11: Assertion 2 — view count is numeric ──────────────────

        Assert.assertTrue(
                viewCount.matches("[0-9]+"),
                "View count is not numeric! Actual value: [" + viewCount + "]"
        );
        System.out.println("✅ Assertion 2 passed — view count is numeric: " + viewCount);

        System.out.println("✅ All assertions passed! View count: [" + viewCount + "]");
    }
}