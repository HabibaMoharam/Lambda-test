package tests;

import base.BaseTests;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class AskQuestionTest extends BaseTests {

    // ── Test credentials ──────────────────────────────────────────────────
    private final String email    = "jojo@hotmail.com";
    private final String password = "test@222";

    @Test
    public void verifyAskQuestionFormIsDisplayed() {

        // ── Step 1: Create page objects ───────────────────────────────────
        HomePage    homePage    = new HomePage(driver, wait);
        LoginPagePro loginPage   = new LoginPagePro(driver, wait);
        BrandPage   brandPage   = new BrandPage(driver, wait);
        ProductPage productPage = new ProductPage(driver, wait);

        // ── Step 2: Login ─────────────────────────────────────────────────
        // ✅ REUSED — exact same as all previous tests
        loginPage.loginAs(
                homePage.getMyAccountMenu(),
                email,
                password
        );
        Assert.assertTrue(
                loginPage.getCurrentUrl().contains("account/account"),
                "Login failed! Cannot proceed to ask question test."
        );
        System.out.println("✅ Login successful");

        // ── Step 3: Go back to home page ──────────────────────────────────
        // ✅ REUSED — same as all previous tests
        driver.navigate().to("https://ecommerce-playground.lambdatest.io/");
        homePage.waitForPageToLoad();
        System.out.println("✅ Home page loaded");

        // ── Step 4: Navigate Mega Menu → Apple brand page ─────────────────
        // ✅ REUSED — same as all previous tests
        homePage.navigateToAppleBrand();

        // ── Step 5: Confirm we are on Apple brand page ────────────────────
        // ✅ REUSED — same as ProductViewTest
        String brandName = brandPage.getBrandName();
        System.out.println("✅ On brand page: " + brandName);

        // ── Step 6: Click iPod Shuffle ────────────────────────────────────
        // ✅ REUSED — clickProductByViewCount() targets iPod Shuffle by name
        homePage.clickProductByViewCount();

        // ── Step 7: Wait for product detail page to load ──────────────────
        // ✅ REUSED — same as all previous tests
        productPage.waitForPageToLoad();
        System.out.println("✅ Product detail page loaded: " + driver.getCurrentUrl());

        // ── Step 8: Read product title for logging ────────────────────────
        // ✅ REUSED — same as all previous tests
        String productTitle = productPage.getProductTitle();
        System.out.println("✅ Product name: " + productTitle);

        // ── Step 9: Click "Ask Question" button ───────────────────────────
        // ✅ NEW — clickAskQuestion() added in Step 1
        productPage.clickAskQuestion();
        System.out.println("✅ Ask Question button clicked");

        // ── Step 10: Assert the question form is displayed ────────────────
        // ✅ NEW — isQuestionFormDisplayed() added in Step 1
        Assert.assertTrue(
                productPage.isQuestionFormDisplayed(),
                "Ask Question form is NOT displayed after clicking the button!"
        );
        System.out.println("✅ Ask Question form is displayed correctly");
    }
}