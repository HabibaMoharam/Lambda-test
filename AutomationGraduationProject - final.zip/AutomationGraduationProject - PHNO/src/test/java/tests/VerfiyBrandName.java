package tests;

import base.BaseTests;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class VerfiyBrandName extends BaseTests
{

    // ── Test credentials ──────────────────────────────────────────────────
    private final String email    = "jojo@hotmail.com";
    private final String password = "test@222";

    @Test
    public void loginAndValidateBrandTest() {

        // ── Step 1: Create page objects ───────────────────────────────────
        // Each page receives driver and wait from BaseTest (protected)
        HomePage    homePage    = new HomePage(driver, wait);
        LoginPagePro loginPage   = new LoginPagePro(driver, wait);
        BrandPage   brandPage   = new BrandPage(driver, wait);
        ProductPage productPage = new ProductPage(driver, wait);

        // ── Step 2: Login ─────────────────────────────────────────────────
        loginPage.loginAs(
                homePage.getMyAccountMenu(), // the My Account button on home page
                email,
                password
        );

        // Assert login success
        Assert.assertTrue(
                loginPage.getCurrentUrl().contains("account/account"),
                "Login failed!"
        );
        System.out.println(" Login successful");

        // ── Step 3: Go back to home page ──────────────────────────────────
        driver.navigate().to("https://ecommerce-playground.lambdatest.io/");
        homePage.waitForPageToLoad();

        // ── Step 4: Navigate Mega Menu → Apple brand page ─────────────────
        homePage.navigateToAppleBrand();

        // ── Step 5: Capture brand name BEFORE clicking any product ────────
        String expectedBrand = brandPage.getBrandName();

        // ── Step 6: Click the first product ──────────────────────────────
        brandPage.clickFirstProduct();

        // ── Step 7: Wait for product detail page to load ─────────────────
        productPage.waitForPageToLoad();

        // ── Step 8: Assert product title is visible ───────────────────────
        String productTitle = productPage.getProductTitle();
        Assert.assertFalse(
                productTitle.isEmpty(),
                "Product title should not be empty!"
        );
        System.out.println(" Product page loaded: " + productTitle);

        // ── Step 9: Assert brand name matches ─────────────────────────────
        String actualBrand = productPage.getBrandName(expectedBrand);
        Assert.assertEquals(
                actualBrand,
                expectedBrand,
                "Brand mismatch! Expected: [" + expectedBrand + "] but found: [" + actualBrand + "]"
        );
        System.out.println(" Brand assertion passed! '" + actualBrand + "' matches.");
    }
}
