package tests;

import base.BaseTests;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class ProductCodeTest extends BaseTests {

    private final String email    = "jojo@hotmail.com";
    private final String password = "test@222";

    @Test
    public void verifyProductCodeIsDisplayed() {

        // ── Step 1: Create page objects ───────────────────────────────────
        HomePage    homePage    = new HomePage(driver, wait);
        LoginPagePro loginPage   = new LoginPagePro(driver, wait);
        BrandPage   brandPage   = new BrandPage(driver, wait);
        ProductPage productPage = new ProductPage(driver, wait);

        // ── Step 2: Login ─────────────────────────────────────────────────
        loginPage.loginAs(
                homePage.getMyAccountMenu(),
                email,
                password
        );
        Assert.assertTrue(
                loginPage.getCurrentUrl().contains("account/account"),
                "Login failed!"
        );
        System.out.println(" Login successful");

        // ── Step 3: Go back to home page ──────────────────────────────────
        driver.navigate().to("https://ecommerce-playground.lambdatest.io/");
        homePage.waitForPageToLoad();
        System.out.println("Home page loaded");

        // ── Step 4: Navigate Mega Menu → Apple brand page ─────────────────
        // SAME as LoginTest — reusing navigateToAppleBrand()
        homePage.navigateToAppleBrand();

        // ── Step 5: Wait for Apple brand page to load ─────────────────────
        //  REUSED — getBrandName() waits for h1 to be visible
        String brandName = brandPage.getBrandName();
        System.out.println(" On brand page: " + brandName);

        // ── Step 6: Click iPod Shuffle on the Apple brand page ────────────
        //  REUSED — clickFirstProduct() now targets iPod Shuffle by name
        homePage.clickFirstProduct();

        // ── Step 7: Wait for product detail page ──────────────────────────
        productPage.waitForPageToLoad();
        System.out.println(" Product detail page loaded: " + driver.getCurrentUrl());

        // ── Step 8: Read product title for logging ────────────────────────
        String productTitle = productPage.getProductTitle();
        System.out.println(" Product name: " + productTitle);

        // ── Step 9: Read and assert product code ──────────────────────────
        String productCode = productPage.getProductCode();

        Assert.assertFalse(
                productCode.isEmpty(),
                "Product code is empty! It should be displayed on the page."
        );
        Assert.assertTrue(
                productCode.trim().length() > 0,
                "Product code contains only spaces!"
        );
        System.out.println(" Product code assertion passed! Code: [" + productCode + "]");
    }
}