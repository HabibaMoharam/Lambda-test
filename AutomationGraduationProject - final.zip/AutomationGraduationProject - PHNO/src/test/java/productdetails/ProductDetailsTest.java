package productdetails;

import base.BaseTests;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.BrandPage;
import pages.HomePage;
import pages.LoginPagePro;
import pages.ProductPage;

public class ProductDetailsTest extends BaseTests {

    private final String email = "jojo@hotmail.com";
    private final String password = "test@222";

    @Test(priority = 1)
    public void verifyBrandName() {
        HomePage homePage = new HomePage(driver,wait);
        LoginPagePro loginPage = new LoginPagePro(driver, wait);
        BrandPage brandPage = new BrandPage(driver, wait);
        ProductPage productPage = new ProductPage(driver, wait);

        loginPage.loginAs(homePage.getMyAccountMenu(), email, password);

        Assert.assertTrue(
                loginPage.getCurrentUrl().contains("account/account"),
                "Login failed!"
        );

        driver.navigate().to("https://ecommerce-playground.lambdatest.io/");
        homePage.waitForPageToLoad();

        homePage.navigateToAppleBrand();

        String expectedBrand = brandPage.getBrandName();

        brandPage.clickFirstProduct();

        productPage.waitForPageToLoad();

        String productTitle = productPage.getProductTitle();
        Assert.assertFalse(productTitle.isEmpty(), "Product title should not be empty!");

        String actualBrand = productPage.getBrandName(expectedBrand);

        Assert.assertEquals(
                actualBrand,
                expectedBrand,
                "Brand mismatch! Expected: [" + expectedBrand + "] but found: [" + actualBrand + "]"
        );
    }

    @Test(priority = 2)
    public void verifyProductCodeIsDisplayed() {
        HomePage homePage = new HomePage(driver, wait);
        LoginPagePro loginPage = new LoginPagePro(driver, wait);
        BrandPage brandPage = new BrandPage(driver, wait);
        ProductPage productPage = new ProductPage(driver, wait);

        loginPage.loginAs(homePage.getMyAccountMenu(), email, password);

        Assert.assertTrue(
                loginPage.getCurrentUrl().contains("account/account"),
                "Login failed!"
        );

        driver.navigate().to("https://ecommerce-playground.lambdatest.io/");
        homePage.waitForPageToLoad();

        homePage.navigateToAppleBrand();

        String brandName = brandPage.getBrandName();
        System.out.println("On brand page: " + brandName);

        homePage.clickFirstProduct();

        productPage.waitForPageToLoad();

        String productTitle = productPage.getProductTitle();
        System.out.println("Product name: " + productTitle);

        String productCode = productPage.getProductCode();

        Assert.assertFalse(
                productCode.isEmpty(),
                "Product code is empty! It should be displayed on the page."
        );

        Assert.assertTrue(
                productCode.trim().length() > 0,
                "Product code contains only spaces!"
        );
    }

    @Test(priority = 3)
    public void verifyProductViewCountIsNumeric() {
        HomePage homePage = new HomePage(driver, wait);
        LoginPagePro loginPage = new LoginPagePro(driver, wait);
        BrandPage brandPage = new BrandPage(driver, wait);
        ProductPage productPage = new ProductPage(driver, wait);

        loginPage.loginAs(homePage.getMyAccountMenu(), email, password);

        Assert.assertTrue(
                loginPage.getCurrentUrl().contains("account/account"),
                "Login failed! Cannot proceed to product view test."
        );

        driver.navigate().to("https://ecommerce-playground.lambdatest.io/");
        homePage.waitForPageToLoad();

        homePage.navigateToAppleBrand();

        String brandName = brandPage.getBrandName();
        System.out.println("On brand page: " + brandName);

        homePage.clickProductByViewCount();

        productPage.waitForPageToLoad();

        String productTitle = productPage.getProductTitle();
        System.out.println("Product name: " + productTitle);

        String viewCount = productPage.getViewCount();

        Assert.assertFalse(
                viewCount.isEmpty(),
                "View count is empty! It should be displayed on the page."
        );

        Assert.assertTrue(
                viewCount.matches("[0-9]+"),
                "View count is not numeric! Actual value: [" + viewCount + "]"
        );
    }
}