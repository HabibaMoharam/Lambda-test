package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class EditAccountPage {
    WebDriver driver;

    public EditAccountPage(WebDriver driver) {
        this.driver = driver;
    }

    private By firstName = By.id("input-firstname");
    private By lastName = By.id("input-lastname");
    private By telephone = By.id("input-telephone");
    private By continueButton = By.xpath("//input[@value='Continue']");
    private By successMessage = By.xpath("//div[contains(@class,'alert-success')]");
    private By firstNameError = By.xpath("//input[@id='input-firstname']/following-sibling::div");
    private By lastNameError = By.xpath("//input[@id='input-lastname']/following-sibling::div");

    public void clearFirstName() {
        driver.findElement(firstName).clear();
    }

    public void clearLastName() {
        driver.findElement(lastName).clear();
    }

    public void clearTelephone() {
        driver.findElement(telephone).clear();
    }

    public void enterFirstName(String fname) {
        driver.findElement(firstName).sendKeys(fname);
    }

    public void enterLastName(String lname) {
        driver.findElement(lastName).sendKeys(lname);
    }

    public void enterTelephone(String phone) {
        driver.findElement(telephone).sendKeys(phone);
    }

    public void clickContinueButton() {
        driver.findElement(continueButton).click();
    }

    public String getSuccessMessage() {
        return driver.findElement(successMessage).getText();
    }

    public String getFirstNameErrorMessage() {
        return driver.findElement(firstNameError).getText();
    }

    public String getLastNameErrorMessage() {
        return driver.findElement(lastNameError).getText();
    }
}