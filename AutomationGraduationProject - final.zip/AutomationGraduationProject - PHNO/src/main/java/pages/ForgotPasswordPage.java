package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class ForgotPasswordPage {

    WebDriver driver;
    WebDriverWait wait;

    public ForgotPasswordPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    private By emailField = By.id("input-email");

    private By continueButton = By.xpath(
            "//button[contains(normalize-space(),'Continue')]"
    );

    private By body = By.tagName("body");

    public void openForgotPasswordPage() {
        driver.get("https://ecommerce-playground.lambdatest.io/index.php?route=account/forgotten");
    }

    public void enterEmail(String email) {
        WebElement emailInput = wait.until(ExpectedConditions.visibilityOfElementLocated(emailField));
        emailInput.clear();
        emailInput.sendKeys(email);
    }

    public void clickContinueButton() {
        WebElement button = wait.until(ExpectedConditions.presenceOfElementLocated(continueButton));

        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].scrollIntoView({block:'center'});",
                button
        );

        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].click();",
                button
        );
    }

    public String getPageText() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(body)).getText();
    }

    public void waitForTextOnPage(String expectedText) {
        wait.until(ExpectedConditions.textToBePresentInElementLocated(body, expectedText));
    }
}