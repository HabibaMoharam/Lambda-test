package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductSearchPage {
    WebDriver driver;

    public ProductSearchPage(WebDriver driver) {
        this.driver = driver;
    }

    private By productLinkText =By.linkText("HTC Touch HD");
    private By message = By.xpath("//p[contains(text(),'There is no product that matches the search criteria.')]");

    public String getProductName(){
        String productName = driver.findElement(productLinkText).getText();
        return productName;
    }

    public String getErrorMessage(){
        String errormessage = driver.findElement(message).getText();
        return errormessage;
    }
}
