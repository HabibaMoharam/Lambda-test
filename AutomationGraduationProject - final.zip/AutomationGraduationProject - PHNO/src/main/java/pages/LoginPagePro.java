package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPagePro {

    // ── Driver and wait ───────────────────────────────────────────────────
    private WebDriver driver;
    private WebDriverWait wait;

    // ── Locators — everything related to login lives here ─────────────────
    private By loginLinkInDropdown = By.xpath(
            "//ul[contains(@class,'dropdown-menu')]//a[normalize-space()='Login']"
    );
    private By emailField    = By.id("input-email");
    private By passwordField = By.id("input-password");
    private By loginButton   = By.cssSelector("input[type='submit'][value='Login']");

    // ── Constructor ───────────────────────────────────────────────────────
    public LoginPagePro(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait   = wait;
    }

    // ── Actions ───────────────────────────────────────────────────────────

    // Step 1: Hover over "My Account" to reveal the dropdown
    // We receive the myAccountMenu element from HomePage
    // because it lives on the home page, not the login page
    public void hoverMyAccount(WebElement myAccountMenu) {
        new Actions(driver).moveToElement(myAccountMenu).perform();
    }

    // Step 2: Click "Login" from the dropdown
    public void clickLoginLink() {
        WebElement loginLink = wait.until(
                ExpectedConditions.elementToBeClickable(loginLinkInDropdown)
        );
        loginLink.click();
    }

    // Step 3: Fill the email and password fields
    public void enterCredentials(String email, String password) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(emailField));
        driver.findElement(emailField).sendKeys(email);
        driver.findElement(passwordField).sendKeys(password);
    }

    // Step 4: Click the Login submit button
    public void submitLogin() {
        driver.findElement(loginButton).click();
    }

    // ── Combined method — does all 4 steps in one call ────────────────────
    // This is what the test class will call
    public void loginAs(WebElement myAccountMenu, String email, String password) {
        hoverMyAccount(myAccountMenu);
        clickLoginLink();
        enterCredentials(email, password);
        submitLogin();
    }

    // ── Getter — returns current URL so test can assert ───────────────────
    public String getCurrentUrl() {
        wait.until(ExpectedConditions.urlContains("route=account/account"));
        return driver.getCurrentUrl();
    }
}