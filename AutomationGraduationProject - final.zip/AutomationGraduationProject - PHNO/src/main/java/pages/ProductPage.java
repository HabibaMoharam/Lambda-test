package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class ProductPage {

    // ── Driver and wait ───────────────────────────────────────────────────
    private WebDriver driver;
    private WebDriverWait wait;

    // ── Locators ──────────────────────────────────────────────────────────
    private By productTitle = By.cssSelector("h1");

    private By productCode  = By.xpath(
            "//ul[contains(@class,'list-unstyled')]//li[contains(.,'Product Code:')]//span[last()]"
    );
    private By viewCount = By.xpath(
            "//ul[contains(@class,'list-unstyled')]//li//span[contains(@class,'ls-label') and contains(.,'Viewed:')]/following-sibling::span"
    );


    // "Ask Question" button on the product detail page
    private By askQuestionBtn = By.xpath(
            "//a[contains(@class,'ask-question') or contains(normalize-space(),'Ask Question')]"
    );

    //  the question form that appears after clicking "Ask Question"
// The form appears inside a modal popup
    private By questionForm = By.xpath(
            "//div[contains(@class,'modal') and contains(@class,'show')]//form"
    );

    //   "Add to Wishlist" button on the product detail page
    private By addToWishlistBtn = By.cssSelector("button.btn-wishlist");


    // confirmation message that appears after adding to wishlist
// It appears as an alert/notification at the top of the page
    private By confirmationMessage = By.cssSelector("#notification-box-top .toast.show");



    // — targets the toast notification paragraph containing "You must"
    private By loginPromptModal = By.xpath(
            "//p[contains(.,'You must') and contains(.,'login')]"
    );

    private By loginPromptMessage = By.xpath(
            "//div[contains(@class,'modal') and contains(@class,'show')]//*[contains(.,'login')]"
    );
    // ── Constructor ───────────────────────────────────────────────────────
    public ProductPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait   = wait;
    }

    // ── Actions ───────────────────────────────────────────────────────────

    // Waits for the product detail page URL to confirm we arrived
    public void waitForPageToLoad() {
        wait.until(ExpectedConditions.urlContains("product/product"));
    }

    // Reads the product page title (h1) and returns it
    public String getProductTitle() {
        WebElement title = wait.until(
                ExpectedConditions.visibilityOfElementLocated(productTitle)
        );
        return title.getText().trim();
    }

    // Finds the brand name shown in the product info section
    // Tries 3 selectors because the site HTML varies by product
    public String getBrandName(String expectedBrand) {

        // Try 1: standard class
        try {
            WebElement brandEl = driver.findElement(
                    By.cssSelector(".product-manufacturer a")
            );
            return brandEl.getText().trim();
        } catch (Exception e1) { }

        // Try 2: list item containing word "Brand"
        try {
            WebElement brandEl = driver.findElement(
                    By.xpath("//ul[contains(@class,'list-unstyled')]//li[contains(.,'Brand')]//a")
            );
            return brandEl.getText().trim();
        } catch (Exception e2) { }

        // Try 3: any link whose text matches the expected brand name
        try {
            WebElement brandEl = driver.findElement(
                    By.xpath("//a[normalize-space()='" + expectedBrand + "']")
            );
            return brandEl.getText().trim();
        } catch (Exception e3) { }

        // If all fail — print HTML snippet around "brand" to help debug
        System.out.println(" Could not find brand element. HTML snippet:");
        String pageSource = driver.getPageSource();
        int idx = pageSource.toLowerCase().indexOf("brand");
        if (idx != -1) {
            System.out.println(pageSource.substring(
                    Math.max(0, idx - 100),
                    Math.min(pageSource.length(), idx + 300)
            ));
        }

        return ""; // returns empty — assertion in test will catch this
    }

    public String getProductCode() {
        WebElement codeElement = wait.until(
                ExpectedConditions.visibilityOfElementLocated(productCode)
        );
        String code = codeElement.getText().trim();
        System.out.println("Product code found: " + code);
        return code;
    }

    public String getViewCount() {
        WebElement viewCountElement = wait.until(
                ExpectedConditions.visibilityOfElementLocated(viewCount)
        );
        String count = viewCountElement.getText().trim();
        System.out.println("View count found: " + count);
        return count;
    }




    //  clicks the "Ask Question" button on the product page
    public void clickAskQuestion() {
        WebElement askBtn = wait.until(
                ExpectedConditions.elementToBeClickable(askQuestionBtn)
        );
        System.out.println("Clicking Ask Question button...");
        askBtn.click();
    }

    // checks if the question form modal is displayed
// Returns true if form is visible, false if not
    public boolean isQuestionFormDisplayed() {
        try {
            WebElement form = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(questionForm)
            );
            return form.isDisplayed();
        } catch (Exception e) {
            System.out.println(" Question form not found: " + e.getMessage());
            return false;
        }
    }




    //— handles both logged-in toast and guest login prompt
    public void clickAddToWishlist() {
        WebElement btn = wait.until(
                ExpectedConditions.elementToBeClickable(addToWishlistBtn)
        );
        System.out.println("Wishlist state: " + btn.getAttribute("title"));
        btn.click();

        // Wait for EITHER the toast body OR the login prompt to appear
        wait.until(ExpectedConditions.or(
                ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".toast-body")),
                ExpectedConditions.visibilityOfElementLocated(loginPromptModal)
        ));
        System.out.println("Wishlist action completed");
    }




    // reads and returns the confirmation message text
// Returns empty string if message not found
    public String getConfirmationMessage() {

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        try {

            WebElement toastBody = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(
                            By.cssSelector(".toast-body")
                    )
            );

            wait.until(driver ->
                    !toastBody.getText().trim().isEmpty()
            );

            String text = toastBody.getText().trim();

            System.out.println("Actual toast message: " + text);

            return text;

        } catch (Exception e) {

            System.out.println("Toast message NOT found: " + e.getMessage());

            return "";
        }
    }




    //— checks for the toast message containing login prompt text
    public boolean isLoginPromptDisplayed() {
        try {
            WebElement prompt = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(loginPromptModal)
            );
            String text = prompt.getText().trim();
            System.out.println("Login prompt text: " + text);
            return prompt.isDisplayed();
        } catch (Exception e) {
            System.out.println("❌ Login prompt not found: " + e.getMessage());
            return false;
        }
    }



}