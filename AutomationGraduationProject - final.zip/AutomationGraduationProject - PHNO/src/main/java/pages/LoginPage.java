package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
    WebDriver driver;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    private By email = By.id("input-email");
    private By password = By.id("input-password");
    private By loginButton = By.xpath("//input[@value='Login']");
    private By errorMessage = By.xpath("//div[contains(@class,'alert-danger')]");
    private By myAccountTitle = By.xpath("//h2[text()='My Account']");

    public void enterEmail(String email_address) {
        driver.findElement(email).sendKeys(email_address);
    }

    public void enterPassword(String pass) {
        driver.findElement(password).sendKeys(pass);
    }

    public void clickOnLoginButton() {
        driver.findElement(loginButton).click();
    }

    public String getErrorMessage() {
        return driver.findElement(errorMessage).getText();
    }

    public String getMyAccountTitle() {
        return driver.findElement(myAccountTitle).getText();
    }
}