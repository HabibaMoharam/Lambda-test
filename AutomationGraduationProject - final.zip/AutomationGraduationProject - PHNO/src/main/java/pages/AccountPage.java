package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AccountPage {
    WebDriver driver;

    public AccountPage(WebDriver driver) {
        this.driver = driver;
    }

    private By myAccountHeading = By.xpath("//h2[text()='My Account']");
    private By editAccountLink = By.linkText("Edit your account information");

    public String getMyAccountHeading() {
        return driver.findElement(myAccountHeading).getText();
    }

    public void clickEditAccountInformation() {
        driver.findElement(editAccountLink).click();
    }
}