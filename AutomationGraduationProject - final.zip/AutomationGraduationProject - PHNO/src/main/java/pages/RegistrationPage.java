package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RegistrationPage {
    WebDriver driver;

    public RegistrationPage(WebDriver driver) {
        this.driver = driver;
    }

    private By firstName = By.id("input-firstname");
    private By lastName = By.id("input-lastname");
    private By email = By.id("input-email");
    private By telephone = By.id("input-telephone");
    private By password = By.id("input-password");
    private By confirmPassword = By.id("input-confirm");
    private By privacyPolicy = By.name("agree");
    private By continueButton = By.xpath("//input[@value='Continue']");

    private By successMessage = By.xpath("//h1[contains(text(),'Your Account Has Been Created!')]");
    private By warningMessage = By.xpath("//div[contains(@class,'alert-danger')]");
    private By firstNameError = By.xpath("//input[@id='input-firstname']/following-sibling::div");

    public void enterFirstName(String first_name) {
        driver.findElement(firstName).sendKeys(first_name);
    }

    public void enterLastName(String last_name) {
        driver.findElement(lastName).sendKeys(last_name);
    }

    public void enterEmail(String email_address) {
        driver.findElement(email).sendKeys(email_address);
    }

    public void enterTelephone(String phone) {
        driver.findElement(telephone).sendKeys(phone);
    }

    public void enterPassword(String pass) {
        driver.findElement(password).sendKeys(pass);
    }

    public void enterConfirmPassword(String confirm_pass) {
        driver.findElement(confirmPassword).sendKeys(confirm_pass);
    }

    public void clickOnPrivacyPolicy() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", driver.findElement(privacyPolicy));
    }

    public void clickOnContinueButton() {
        driver.findElement(continueButton).click();
    }

    public String getSuccessMessage() {
        return driver.findElement(successMessage).getText();
    }

    public String getWarningMessage() {
        return driver.findElement(warningMessage).getText();
    }

    public String getFirstNameErrorMessage() {
        return driver.findElement(firstNameError).getText();
    }
}