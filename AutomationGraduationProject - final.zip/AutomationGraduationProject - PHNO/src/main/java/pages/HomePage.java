package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage {
    WebDriver driver;

    public HomePage(WebDriver driver){
        this.driver = driver;
    }

    //Perryhan(Search Product)
    private By searchBar = By.name("search");
    private By searchButton = By.className("type-text");


    public void EnterSearchText(String product_name){
        driver.findElement(searchBar).sendKeys(product_name);
    }

    public ProductSearchPage clickOnSearchButton(){
        driver.findElement(searchButton).click();
        return new ProductSearchPage(driver);
    }


    //habiba(Login+Registration)

    public RegistrationPage clickOnRegister() {
        driver.get("https://ecommerce-playground.lambdatest.io/index.php?route=account/register");
        return new RegistrationPage(driver);
    }

    public LoginPage clickOnLogin() {
        driver.get("https://ecommerce-playground.lambdatest.io/index.php?route=account/login");
        return new LoginPage(driver);
    }

    //Nermeen(Product Details)
    private WebDriverWait wait;

    // ── Locators — all By. live here, never in the test class ─────────────
    private By megaMenuBtn   = By.xpath("//a[contains(@class,'nav-link') and contains(.,'Mega Menu')]");
    private By appleLinkInMenu = By.xpath("//a[@title='Apple' and contains(@href,'manufacturer')]");
    private By myAccountMenu = By.cssSelector("a.nav-link.dropdown-toggle[href*='account']");
    private By productThumb  = By.cssSelector(".product-thumb");


    // ── Constructor — receives driver and wait from the test ───────────────
    public HomePage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait   = wait;
    }

    // ── Actions ───────────────────────────────────────────────────────────

    // Waits for the home page products to be visible (page fully loaded)
    public void waitForPageToLoad() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(productThumb));
    }

    // Hovers over Mega Menu then clicks Apple brand
    public void navigateToAppleBrand() {

        // 1. Hover over Mega Menu to open the dropdown
        WebElement megaMenu = wait.until(
                ExpectedConditions.elementToBeClickable(megaMenuBtn)
        );
        new Actions(driver).moveToElement(megaMenu).perform();

        // 2. Wait for Apple link to appear and click it
        WebElement appleLink = wait.until(
                ExpectedConditions.elementToBeClickable(appleLinkInMenu)
        );
        appleLink.click();

        System.out.println(" Navigated to Apple brand page: " + driver.getCurrentUrl());
    }

    // Returns the MyAccount menu element so LoginPage can hover on it
    public WebElement getMyAccountMenu() {
        return driver.findElement(myAccountMenu);
    }



    // clicks iPod Shuffle on the Apple brand page
    public void clickFirstProduct() {
        WebElement product = wait.until(
                ExpectedConditions.elementToBeClickable(
                        By.xpath("//h4/a[contains(normalize-space(),'iPod Shuffle')]")
                )
        );
        System.out.println("Clicking product: " + product.getText());
        product.click();
    }
    //  NEW — for ProductViewTest only


    public void clickProductByViewCount() {
        WebElement product = wait.until(
                ExpectedConditions.elementToBeClickable(
                        By.xpath("//h4/a[contains(normalize-space(),'iPod Shuffle')]")
                )
        );
        System.out.println("Clicking product: " + product.getText());
        product.click();
    }
}
