package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BrandPage {

    // ── Driver and wait ───────────────────────────────────────────────────
    private WebDriver driver;
    private WebDriverWait wait;

    // ── Locators ──────────────────────────────────────────────────────────
    private By pageHeading  = By.cssSelector("h1");
    private By firstProduct = By.cssSelector(".product-thumb h4 a");

    // ── Constructor ───────────────────────────────────────────────────────
    public BrandPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait   = wait;
    }

    // ── Actions ───────────────────────────────────────────────────────────

    // Reads the h1 heading on the brand page e.g. "Apple"
    // We save this BEFORE clicking any product so we can compare later
    public String getBrandName() {
        WebElement heading = wait.until(
                ExpectedConditions.visibilityOfElementLocated(pageHeading)
        );
        String brandName = heading.getText().trim();
        System.out.println("Brand page title is: " + brandName);
        return brandName;
    }

    // Clicks the first product on the brand page
    public void clickFirstProduct() {
        WebElement product = wait.until(
                ExpectedConditions.elementToBeClickable(firstProduct)
        );
        System.out.println("Clicking product: " + product.getText());
        product.click();
    }
}